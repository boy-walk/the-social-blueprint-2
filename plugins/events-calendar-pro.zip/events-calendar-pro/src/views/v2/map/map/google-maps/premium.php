<?php
/**
 * View: Map View - Google Maps Premium
 *
 * Override this template in your own theme by creating a file at:
 * [your-theme]/tribe/events-pro/v2/map/map/google-maps/premium.php
 *
 * See more documentation about our views templating system.
 *
 * @link https://evnt.is/1aiy
 *
 * @version 5.0.0
 *
 */
?>
<div
	class="tribe-events-pro-map__google-maps-premium"
	data-js="tribe-events-pro-map-google-maps-premium"
>
</div>
