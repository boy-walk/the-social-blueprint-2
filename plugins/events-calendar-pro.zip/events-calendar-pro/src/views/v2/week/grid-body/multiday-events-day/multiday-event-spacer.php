<?php
/**
 * View: Week View - Multiday Event Spacer
 *
 * Override this template in your own theme by creating a file at:
 * [your-theme]/tribe/events-pro/v2/week/grid-body/multiday-events-day/multiday-event-spacer.php
 *
 * See more documentation about our views templating system.
 *
 * @link https://evnt.is/1aiy
 *
 * @version 5.0.0
 *
 */
?>
<div class="tribe-events-pro-week-grid__multiday-event-wrapper tribe-events-pro-week-grid__multiday-event--empty"></div>
