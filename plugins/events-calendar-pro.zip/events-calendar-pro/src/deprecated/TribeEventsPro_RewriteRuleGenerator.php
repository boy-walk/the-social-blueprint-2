<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Rewrite_Rule_Generator' );


	class TribeEventsPro_RewriteRuleGenerator extends Tribe__Events__Pro__Rewrite_Rule_Generator {

	}