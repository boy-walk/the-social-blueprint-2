<?php
_deprecated_file( __FILE__, '4.2', 'Tribe__Events__JSON_LD__Organizer' );
class Tribe__Events__Pro__Google_Data_Markup__Organizer extends Tribe__Events__Google_Data_Markup {}
