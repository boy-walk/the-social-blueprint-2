<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__APM_Filters__APM_Filters' );


	class ECP_APM_Filters extends Tribe__Events__Pro__APM_Filters__APM_Filters {

	}