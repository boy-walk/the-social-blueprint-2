<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Recurrence__Meta' );


	class TribeEventsRecurrenceMeta extends Tribe__Events__Pro__Recurrence__Meta {

	}