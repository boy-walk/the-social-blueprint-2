<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Templates__Single_Organizer' );


	class Tribe_Events_Pro_Single_Organizer_Template extends Tribe__Events__Pro__Templates__Single_Organizer {

	}