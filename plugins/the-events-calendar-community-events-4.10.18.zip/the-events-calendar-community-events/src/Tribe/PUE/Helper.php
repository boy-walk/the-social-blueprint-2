<?php

class Tribe__Events__Community__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = 'a5d256c19d501d0e771a97790495b76794020077';

}
