<p class="tribe-common-g-col">
	<?php esc_html_e( 'Event creation and editing have been disabled on this site while it is undergoing maintenance. Thank you for your patience.', 'tribe-events-community' ); ?>
</p>
