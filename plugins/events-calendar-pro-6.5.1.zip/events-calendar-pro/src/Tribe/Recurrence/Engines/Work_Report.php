<?php
/**
 * A value object representing the result of a recurring event update or its preview.
 *
 * @since 4.7
 */

class Tribe__Events__Pro__Recurrence__Engines__Work_Report {
}