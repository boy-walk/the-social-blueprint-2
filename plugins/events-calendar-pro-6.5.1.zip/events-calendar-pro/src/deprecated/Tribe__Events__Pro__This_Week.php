<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__This_Week {
	public static function instance() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function __construct() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function ajax_change_this_week() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function this_week_template_vars( $this_week_query_vars ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function this_week_data_attr( $this_week_query_vars ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function get_day_range( ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function this_week_query( $this_week_query_vars ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}