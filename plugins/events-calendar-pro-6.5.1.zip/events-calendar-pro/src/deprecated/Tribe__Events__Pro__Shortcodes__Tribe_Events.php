<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Shortcodes__Tribe_Events extends \Tribe\Events\Pro\Views\V2\Shortcodes\Tribe_Events {

	public function __construct() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_assets() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_day() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_list() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_map() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_month() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_photo() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_week() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_query() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prepare_default() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function filter_tribe_disable_bar( $value, $option_name ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function enable_tribe_bar() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function update_query( array $arguments ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_query_args() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_url_param( $param, $default = null ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function reset_query() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_attributes() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_attribute( $name, $default = null ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function set_current_page() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function is_attribute_truthy( $name, $true_by_default = false ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_template_object() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function set_template_object( $template_object ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function get_view_handler() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function render_view() {
		_deprecated_function( __METHOD__, '6.0.0' );

		return $this->output();
	}

	public function modify_view_urls( array $views ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function output() {
		_deprecated_function( __METHOD__, '6.0.0' );

		return $this->get_html();
	}
}