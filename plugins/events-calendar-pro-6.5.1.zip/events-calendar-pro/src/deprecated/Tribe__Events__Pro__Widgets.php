<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Widgets {
	public static function form_tax_query( $filters, $operand ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function enqueue_calendar_widget_styles() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}